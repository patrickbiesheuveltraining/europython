from Simulation import Simulation
from Die2 import Die

def test():
    return 1

def main():
    die = Die()
    sim = Simulation(die.roll, 10)
    for item in sim._results:
        print(item)

    # we got print(sim.get_mean())
    print(sim.mean, sim.median, sim.mode)
    
main()
