from Circle1 import Circle

c = Circle(10, 'd')
a = c.area
print(a)

c.radius = 8
a = c.area
print(a)