# Test MyList:

from MyList import MyList
   
mylist = MyList(['a','b','c'])
mylist.append('y')
mylist.prepend('z')
print(mylist)