import requests
from bs4 import BeautifulSoup
import re

url = 'https://www.webucator.com/course-demos/python/courselist.cfm'
headers = {'user-agent': 'my-app/0.0.1'}

# Finish the code

# Challenge:
from collections import Counter

# finish the code