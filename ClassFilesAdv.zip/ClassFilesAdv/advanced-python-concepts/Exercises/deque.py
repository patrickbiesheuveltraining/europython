from collections import deque

todays_agenda=deque(['Staff meeting at 10AM',
	'Database upgrade late AM',
	'Accounts payable software test at 2PM',
'System maintenance in the evening'])

items_added_start_of_day=['Conference call with London customer',
	'Brew a good pot of coffee!']
item_inserted='Accounts receivables unit test, late afternoon'
item_added_late_night='Restart servers'