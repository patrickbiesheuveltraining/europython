from collections import OrderedDict

order_status =  {'O': 'open', 'S': 'shipped', 'B': 'backordered', 'X': 'cancelled', 'R': 'returned'}