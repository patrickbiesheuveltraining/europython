import datetime

def str_to_date(str_date):
    #Write function
    return 'nop'   # placeholder so that code will compile 

str_date = input('Input date as YYYY-MM-DD: ')
date = str_to_date(str_date)
print (date)