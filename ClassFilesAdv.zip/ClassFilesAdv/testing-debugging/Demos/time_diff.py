import time

t1 = time.perf_counter()
t2 = time.perf_counter()
print(t1, t2, t2-t1)