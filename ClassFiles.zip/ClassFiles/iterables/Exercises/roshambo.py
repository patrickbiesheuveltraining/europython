import random

def main():
    pass #replace this with your code

main()