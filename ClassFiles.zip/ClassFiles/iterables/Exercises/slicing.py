import math

def split_list(orig_list):
    #pass #replace this with your code
    
def main():
    colors = ['red','blue','green','orange','purple']
    colors_split = split_list(colors)
    print(colors_split[0])
    print(colors_split[1])

main()