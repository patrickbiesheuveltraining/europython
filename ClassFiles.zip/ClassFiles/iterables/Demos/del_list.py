colors = ['red','blue','green','orange','black']

del colors[0] #deletes first element
print(colors) #['blue', 'green', 'orange','black']

del colors[1:3] #deletes 2nd and 3rd elements
print(colors) #['blue', 'black']