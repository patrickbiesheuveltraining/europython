grades = {'English':97, 'Math':93, 'Global Studies':85, 'Art':74, 'Music':86}

del grades['Math'] #deletes Math key
print(grades) #{'English':97, 'Global Studies':85, 'Art':74, 'Music':86}