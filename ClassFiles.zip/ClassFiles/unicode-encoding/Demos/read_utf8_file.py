with open('./unicode-encoding/Demos/characters_utf.txt', encoding='cp1252') as f:
    print(f.read())