# Convert decimal 100 to hex:
print(hex(100))
# Convert the decimal number 10 to a binary number:
print(bin(10))
#Convert the binary number 101 to a decimal number:
print(int('101', 2))
# Convert the decimal number 1000 to a hexadecimal number:
print(hex(1000))
# Convert the binary number 10010 to a hexadecimal number:
print(hex( int('10010', 2) ))