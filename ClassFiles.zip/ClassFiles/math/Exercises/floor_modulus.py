#write the divide() function

def main():
    numerator = 5
    denominator = 2
    divide(numerator,denominator)

main()