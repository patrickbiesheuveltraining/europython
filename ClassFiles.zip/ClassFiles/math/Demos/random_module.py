import random

print("\nrandom.random()")
print(random.random()) #Returns random float between 0 and 1