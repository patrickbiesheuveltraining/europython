a = 5
a+=2
print(a) #returns 7
a-=2
print(a) #returns 5
a*=2
print(a) #returns 10
print(type(a)) #returns <class 'int'>
a/=2
print(a) #returns 5.0
print(type(a)) #returns <class 'float'>
a%=2
print(a) #returns 1.0
a**=2
print(a) #returns 1.0
a//=2
print(a) #returns 0.0