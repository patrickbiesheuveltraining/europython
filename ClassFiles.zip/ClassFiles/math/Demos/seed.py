import random

seed = 1234
random.seed(seed)

for a in range(1,5):
    print(random.randint(1,10))