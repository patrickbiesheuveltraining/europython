print(5+2) #returns 7
print(5-2) #returns 3
print(5*2) #returns 10
print(5/2) #returns 2.5
print(5%2) #returns 1
print(5**2) #returns 25
print(5//2) #returns 2