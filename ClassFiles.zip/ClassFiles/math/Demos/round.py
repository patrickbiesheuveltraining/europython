print(round(3.14)) #Returns 3
print(round(-3.14)) #Returns -3
print(round(3.14,1)) #Returns 3.1
print(round(3.95,1)) #Returns 4.0
print(round(1111,0)) #Returns 1111
print(round(1111,-2)) #Returns 1100