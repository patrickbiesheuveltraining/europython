i = 1
for item in ['a','b','c']:
    print(i, item, sep='. ')
    i += 1