for item in enumerate(['a','b','c'],1):
    print(item[0], item[1], sep='. ')