f = open('my_files/zen_of_python.txt')
for line in f:
    print(line,end='')
f.close()