import os
dir_contents = os.listdir()
for item in dir_contents:
    print(item)