f = open('my_files/zen_of_python.txt')
file_contents = f.read()
print(file_contents)
f.close()