import sys

def main(args):
    for arg in args:
        print(arg)
        
if __name__ == '__main__':
    main(sys.argv)