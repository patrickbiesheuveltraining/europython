pos = "Hello World!".find("l")
print(pos)

pos = "Hello World!".rfind("l")
print(pos)

pos = "Hello World!".index("l")
print(pos)

pos = "Hello World!".rindex("l")
print(pos)


pos = "Hello World!".find("x")
print(pos)

pos = "Hello World!".index("x")
print(pos)