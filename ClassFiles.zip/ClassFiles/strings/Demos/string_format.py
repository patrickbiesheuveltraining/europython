first_name = input("What is your first name? ")
print("Hello, {0}".format(first_name))