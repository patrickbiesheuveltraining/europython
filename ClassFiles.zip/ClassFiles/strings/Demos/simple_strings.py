sentence1 = "Where'd you get the coconuts?"
sentence2 = 'With keen interest, the soldier asked, "Are you suggesting coconuts migrate?"'
sentence3 = "The soldier said, \"You've got two empty halves of coconut and you're bangin' 'em together.\""
sentence4 = 'The soldier said, "You\'ve got two empty halves of coconut and you\'re bangin\' \'em together."'

print(sentence1)
print(sentence2)
print(sentence3)
print(sentence4)