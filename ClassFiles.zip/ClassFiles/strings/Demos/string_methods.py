quote = "Simpson's Individual Stringettes!"
print(quote)
quote=quote.upper()
print(quote)
quote=quote.lower()
print(quote)
quote=quote.capitalize()
print(quote)



count_in=quote.count("in")
print(count_in)

endswith = quote.endswith("es!")
print(endswith)

son_position = quote.find("son")
print(son_position)