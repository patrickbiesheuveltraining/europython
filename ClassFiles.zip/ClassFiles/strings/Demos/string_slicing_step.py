secret_message = "Mabecdsefsghaijgklemn opfqrostruv wxyyzoabucd,ef ghsigiklrmn.op"
decoded_message = secret_message[::3]
print(decoded_message)

backwards_message = decoded_message[::-1]
print(backwards_message)