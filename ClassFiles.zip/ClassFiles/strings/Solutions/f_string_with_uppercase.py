def main():
    user_name = input("Enter your name: ")
    print(f"Hello, {user_name}! Your name in uppercase is {user_name.upper()}.")
main()