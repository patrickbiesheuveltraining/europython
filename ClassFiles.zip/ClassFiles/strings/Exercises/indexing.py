def main():
    pass #Replace this line with your code

main()