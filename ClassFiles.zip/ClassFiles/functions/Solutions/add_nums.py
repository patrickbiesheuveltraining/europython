def add_nums(num1,num2):
    sum = num1 + num2
    print(num1, '+', num2, ' = ', sum)

def main():
    add_nums(3,6)
    add_nums(10,12)

main()