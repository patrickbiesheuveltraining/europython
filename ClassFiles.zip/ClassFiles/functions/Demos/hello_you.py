def say_hello():
    your_name = input('What is your name? ')
    print('Hello, ', your_name, '!', sep='')

def main():
    say_hello()

main()