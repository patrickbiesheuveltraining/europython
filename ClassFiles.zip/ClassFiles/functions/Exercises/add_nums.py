def add_3_and_6():
    sum = 3 + 6
    print('3 + 6 = ', sum)

def add_10_and_12():
    sum = 10 + 12
    print('10 + 12 = ', sum)

def main():
    add_3_and_6()
    add_10_and_12()

main()