today = "Monday"
print(today)