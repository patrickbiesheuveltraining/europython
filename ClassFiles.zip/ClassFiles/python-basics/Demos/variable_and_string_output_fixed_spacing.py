def main():
    today = "Monday"
    print("Today is", end=" ")
    print(today,".",sep="")
main()