def main():
    today = input("What day is it? ")
    print("Wow! Today is", today, end="")
    print("? Awesome!")

main()