greeting = "Hello, world!"
print(greeting)